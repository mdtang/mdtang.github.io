Welcome to Music Kings Lyrics and Music Generator!

Our generator features two awesome functions:
1) If you choose 1, our generator will randomly generate lyrics with the pattern of three music kings: The Beatles, Elvis Preseley, and Michael Jackson. Each of the artists' lyrics could be used as the sources of VerseOne, VerseTwo, and Chorus. The sequence for this is totally random.
2) If you choose 2, our generator will produce a music file with the name of the music randomly generated using Michael Jackson's lyrics!

To run the program, simply open terminal (Mac)/cmd (Windows), navigate to the directory where generate.py is and then type “python generate.py” (without the quotes)!
Play around and have fun!