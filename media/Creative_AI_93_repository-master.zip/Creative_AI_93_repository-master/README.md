# Creative AI Project

**Creative AI** is about using artificial intelligence to automatically generate lyrics and music using datasets of your choice.

- <a href="https://youtu.be/Z46LvHwgygs?list=PL2BYDiR6uDOJzYCJ7QuuQz-hWvQeYN5Nx" target="_blank">Link to generated lyrics demo</a>

- <a href="https://youtu.be/RrHrRqZ3pUM?list=PL2BYDiR6uDOJzYCJ7QuuQz-hWvQeYN5Nx" target="_blank">Link to generated music demo</a>

- <a href="https://github.com/eecs183/creative-ai/wiki" target="_blank">Link to specification</a>
